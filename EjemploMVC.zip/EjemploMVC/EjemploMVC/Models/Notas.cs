﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EjemploMVC.Models
{
    public class Notas
    {
        public int n1 { get; set; }
        public int n2 { get; set; }
        public int n3 { get; set; }

    }
}