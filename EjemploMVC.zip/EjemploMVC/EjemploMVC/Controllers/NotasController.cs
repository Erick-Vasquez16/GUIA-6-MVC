﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using EjemploMVC.Models;
using System.Web.Mvc;

namespace EjemploMVC.Controllers
{
    public class NotasController : Controller
    {
        // GET: Notas
        public ActionResult Notas()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Notas(Notas obCalculo)
        {
            double resultado = (obCalculo.n1 + obCalculo.n2 + obCalculo.n3) / 3;
            if (resultado >= 7 & resultado < 10)
            {
                ViewBag.resultado = resultado + " Aprobado";
            }
            else if (resultado == 10)
            {
                ViewBag.resultado = resultado + " Felicitaciones";
            }
            else if (resultado <= 4)
            {
                ViewBag.resultado = resultado + " Reprobado Visite a un tutor urgente";
            }
            return View(obCalculo);

        }
    }
}